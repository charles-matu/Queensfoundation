from flask import Flask, render_template,jsonify,request,url_for,redirect
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/about')
def about():
    return render_template('about.html')

#@app.route('/programs')
#def programs():
   # return render_template('programs.html')

@app.route('/shop')
def shop():
    return render_template('shop.html')

@app.route('/programs')
def programs():
    return render_template('impact.html')

@app.route('/blogs')
def blogs():
    return render_template('blogs.html')

@app.route('/contact',methods=['GET','POST'])
def contact():

    return render_template('contact.html')

@app.route('/submit_contact_form', methods=['POST'])
def submit_contact_form():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        message = request.form['message']

        # Email configuration
        sender_email = "favorediotproject@gmail.com"  # Replace with your email
        receiver_email = email  # Replace with recipient email
        password = "nwscrupvjrgeiail"  # Replace with your email password

        msg = MIMEMultipart()
        msg['From'] = receiver_email
        msg['To'] = sender_email
        msg['Subject'] = "Message from Contact Form"

        body = f"Name: {name}\nEmail: {email}\n\nMessage:\n{message}"
        msg.attach(MIMEText(body, 'plain'))

        # Connect to SMTP server and send email
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:  # Replace with your SMTP server
            server.login(sender_email, password)
            server.send_message(msg)

        return redirect(url_for('thank_you'))
    else:
        return 'Method Not Allowed', 405

@app.route('/thank_you')
def thank_you():
    return render_template('thank_you.html')
@app.route('/thank_you_donor')
def thank_you_donor():
    return render_template('thank_you_donor.html')

@app.route('/donate')
def donate():
    return render_template('donate.html')


@app.route('/process_email', methods=['POST'])
def process_email():
    data = request.json
    email = data['email']
    # Process the email here (e.g., send it via email)
    print('Email received:', email)
    sender_email = "favorediotproject@gmail.com"  # Replace with your email
    receiver_email = email  # Replace with recipient email
    password = "nwscrupvjrgeiail"  # Replace with your email password

    msg = MIMEMultipart()
    msg['From'] = receiver_email
    msg['To'] = sender_email
    msg['Subject'] = "DONATION!!"

    body = f"Email: {email}\n HAS DONATED"
    msg.attach(MIMEText(body, 'plain'))

    # Connect to SMTP server and send email
    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:  # Replace with your SMTP server
        server.login(sender_email, password)
        server.send_message(msg)
    # Return a response
    return jsonify({'message': 'Email received successfully'}), 200
@app.route('/payment_options')
def payment_options():



    return render_template('payment_options.html')

@app.route('/gallery')
def gallery():
    return render_template('gallery.html')

@app.route('/faq')
def faq():
    return render_template('faq.html')

if __name__ == '__main__':
    app.run(debug=True)
